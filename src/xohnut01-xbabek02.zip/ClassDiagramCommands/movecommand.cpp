#include "movecommand.h"

MoveCommand::MoveCommand(QObject *parent) : QObject(parent)
{

}
