/********************************************************************************
** Form generated from reading UI file 'sequencediagramwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEQUENCEDIAGRAMWINDOW_H
#define UI_SEQUENCEDIAGRAMWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SequenceDiagramWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_4;
    QGraphicsView *graphicsView;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QListView *classesView;
    QLabel *label_2;
    QListView *instancesView;
    QLabel *label_4;
    QListView *methodView;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_3;
    QPushButton *openFileButton;
    QPushButton *saveFileButton;
    QPushButton *createInstanceButton;
    QPushButton *deleteInstanceButton;
    QPushButton *visibilityButton;
    QPushButton *prolongueButton;
    QPushButton *shortenButton;
    QPushButton *addInitBlockButton;
    QPushButton *prolongueBlockButton;
    QPushButton *shortenBlockButton;
    QPushButton *syncAsyncButton;
    QPushButton *returnMessageButton;
    QPushButton *setMethodButton;
    QSpacerItem *verticalSpacer_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *SequenceDiagramWindow)
    {
        if (SequenceDiagramWindow->objectName().isEmpty())
            SequenceDiagramWindow->setObjectName(QStringLiteral("SequenceDiagramWindow"));
        SequenceDiagramWindow->setEnabled(true);
        SequenceDiagramWindow->resize(1163, 736);
        centralwidget = new QWidget(SequenceDiagramWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        horizontalLayout_4 = new QHBoxLayout(centralwidget);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        graphicsView = new QGraphicsView(centralwidget);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setEnabled(true);

        horizontalLayout_4->addWidget(graphicsView);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setFrameShadow(QFrame::Plain);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label);

        classesView = new QListView(centralwidget);
        classesView->setObjectName(QStringLiteral("classesView"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(classesView->sizePolicy().hasHeightForWidth());
        classesView->setSizePolicy(sizePolicy);

        verticalLayout_3->addWidget(classesView);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_2);

        instancesView = new QListView(centralwidget);
        instancesView->setObjectName(QStringLiteral("instancesView"));
        sizePolicy.setHeightForWidth(instancesView->sizePolicy().hasHeightForWidth());
        instancesView->setSizePolicy(sizePolicy);

        verticalLayout_3->addWidget(instancesView);

        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_4);

        methodView = new QListView(centralwidget);
        methodView->setObjectName(QStringLiteral("methodView"));
        sizePolicy.setHeightForWidth(methodView->sizePolicy().hasHeightForWidth());
        methodView->setSizePolicy(sizePolicy);

        verticalLayout_3->addWidget(methodView);


        horizontalLayout_2->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(label_3);

        openFileButton = new QPushButton(centralwidget);
        openFileButton->setObjectName(QStringLiteral("openFileButton"));

        verticalLayout_4->addWidget(openFileButton);

        saveFileButton = new QPushButton(centralwidget);
        saveFileButton->setObjectName(QStringLiteral("saveFileButton"));

        verticalLayout_4->addWidget(saveFileButton);

        createInstanceButton = new QPushButton(centralwidget);
        createInstanceButton->setObjectName(QStringLiteral("createInstanceButton"));

        verticalLayout_4->addWidget(createInstanceButton);

        deleteInstanceButton = new QPushButton(centralwidget);
        deleteInstanceButton->setObjectName(QStringLiteral("deleteInstanceButton"));

        verticalLayout_4->addWidget(deleteInstanceButton);

        visibilityButton = new QPushButton(centralwidget);
        visibilityButton->setObjectName(QStringLiteral("visibilityButton"));

        verticalLayout_4->addWidget(visibilityButton);

        prolongueButton = new QPushButton(centralwidget);
        prolongueButton->setObjectName(QStringLiteral("prolongueButton"));

        verticalLayout_4->addWidget(prolongueButton);

        shortenButton = new QPushButton(centralwidget);
        shortenButton->setObjectName(QStringLiteral("shortenButton"));

        verticalLayout_4->addWidget(shortenButton);

        addInitBlockButton = new QPushButton(centralwidget);
        addInitBlockButton->setObjectName(QStringLiteral("addInitBlockButton"));

        verticalLayout_4->addWidget(addInitBlockButton);

        prolongueBlockButton = new QPushButton(centralwidget);
        prolongueBlockButton->setObjectName(QStringLiteral("prolongueBlockButton"));

        verticalLayout_4->addWidget(prolongueBlockButton);

        shortenBlockButton = new QPushButton(centralwidget);
        shortenBlockButton->setObjectName(QStringLiteral("shortenBlockButton"));

        verticalLayout_4->addWidget(shortenBlockButton);

        syncAsyncButton = new QPushButton(centralwidget);
        syncAsyncButton->setObjectName(QStringLiteral("syncAsyncButton"));

        verticalLayout_4->addWidget(syncAsyncButton);

        returnMessageButton = new QPushButton(centralwidget);
        returnMessageButton->setObjectName(QStringLiteral("returnMessageButton"));

        verticalLayout_4->addWidget(returnMessageButton);

        setMethodButton = new QPushButton(centralwidget);
        setMethodButton->setObjectName(QStringLiteral("setMethodButton"));

        verticalLayout_4->addWidget(setMethodButton);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_2);


        horizontalLayout_2->addLayout(verticalLayout_4);


        horizontalLayout_4->addLayout(horizontalLayout_2);

        SequenceDiagramWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(SequenceDiagramWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1163, 25));
        SequenceDiagramWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(SequenceDiagramWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        SequenceDiagramWindow->setStatusBar(statusbar);

        retranslateUi(SequenceDiagramWindow);

        QMetaObject::connectSlotsByName(SequenceDiagramWindow);
    } // setupUi

    void retranslateUi(QMainWindow *SequenceDiagramWindow)
    {
        SequenceDiagramWindow->setWindowTitle(QApplication::translate("SequenceDiagramWindow", "MainWindow", 0));
        label->setText(QApplication::translate("SequenceDiagramWindow", "Classes", 0));
        label_2->setText(QApplication::translate("SequenceDiagramWindow", "Instances", 0));
        label_4->setText(QApplication::translate("SequenceDiagramWindow", "Methods", 0));
        label_3->setText(QApplication::translate("SequenceDiagramWindow", "Functions", 0));
        openFileButton->setText(QApplication::translate("SequenceDiagramWindow", "Open File", 0));
        saveFileButton->setText(QApplication::translate("SequenceDiagramWindow", "Save File", 0));
        createInstanceButton->setText(QApplication::translate("SequenceDiagramWindow", "Create Instance", 0));
        deleteInstanceButton->setText(QApplication::translate("SequenceDiagramWindow", "Delete Instance", 0));
        visibilityButton->setText(QApplication::translate("SequenceDiagramWindow", "Instance Visibility", 0));
        prolongueButton->setText(QApplication::translate("SequenceDiagramWindow", "Prolongue line", 0));
        shortenButton->setText(QApplication::translate("SequenceDiagramWindow", "Shorten line", 0));
        addInitBlockButton->setText(QApplication::translate("SequenceDiagramWindow", "Add initial block", 0));
        prolongueBlockButton->setText(QApplication::translate("SequenceDiagramWindow", "Prolongue block", 0));
        shortenBlockButton->setText(QApplication::translate("SequenceDiagramWindow", "Shorten block", 0));
        syncAsyncButton->setText(QApplication::translate("SequenceDiagramWindow", "Sync/Async", 0));
        returnMessageButton->setText(QApplication::translate("SequenceDiagramWindow", "Return Message", 0));
        setMethodButton->setText(QApplication::translate("SequenceDiagramWindow", "Set Method", 0));
    } // retranslateUi

};

namespace Ui {
    class SequenceDiagramWindow: public Ui_SequenceDiagramWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEQUENCEDIAGRAMWINDOW_H
